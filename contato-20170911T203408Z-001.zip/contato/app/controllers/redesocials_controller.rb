class RedesocialsController < ApplicationController
  before_action :set_redesocial, only: [:show, :edit, :update, :destroy]

  # GET /redesocials
  # GET /redesocials.json
  def index
    @redesocials = Redesocial.all
  end

  # GET /redesocials/1
  # GET /redesocials/1.json
  def show
  end

  # GET /redesocials/new
  def new
    @redesocial = Redesocial.new
  end

  # GET /redesocials/1/edit
  def edit
  end

  # POST /redesocials
  # POST /redesocials.json
  def create
    @redesocial = Redesocial.new(redesocial_params)

    respond_to do |format|
      if @redesocial.save
        format.html { redirect_to @redesocial, notice: 'Redesocial was successfully created.' }
        format.json { render :show, status: :created, location: @redesocial }
      else
        format.html { render :new }
        format.json { render json: @redesocial.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /redesocials/1
  # PATCH/PUT /redesocials/1.json
  def update
    respond_to do |format|
      if @redesocial.update(redesocial_params)
        format.html { redirect_to @redesocial, notice: 'Redesocial was successfully updated.' }
        format.json { render :show, status: :ok, location: @redesocial }
      else
        format.html { render :edit }
        format.json { render json: @redesocial.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /redesocials/1
  # DELETE /redesocials/1.json
  def destroy
    @redesocial.destroy
    respond_to do |format|
      format.html { redirect_to redesocials_url, notice: 'Redesocial was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_redesocial
      @redesocial = Redesocial.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def redesocial_params
      params.require(:redesocial).permit(:nome, :email, :telefone, :idade)
    end
end
