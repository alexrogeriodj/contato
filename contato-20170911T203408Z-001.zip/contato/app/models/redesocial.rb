class Redesocial < ActiveRecord::Base
end
