class CreateRedesocials < ActiveRecord::Migration
  def change
    create_table :redesocials do |t|
      t.string :nome
      t.string :email
      t.string :telefone
      t.string :idade

      t.timestamps null: false
    end
  end
end
